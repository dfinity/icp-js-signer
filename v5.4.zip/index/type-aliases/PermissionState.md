---
title: PermissionState
editUrl: false
next: true
prev: true
---

> **PermissionState** = `"denied"` \| `"ask_on_use"` \| `"granted"`

Defined in: [src/signer.ts:96](https://github.com/dfinity/icp-js-signer/blob/05046af0774fe292d4b76290de5a787d2a119c35/src/signer.ts#L96)

The state of a permission scope as reported by the signer.
- `granted` — the relying party may call the method without further approval.
- `denied` — the signer will reject calls to the method.
- `ask_on_use` — the signer will prompt the user when the method is called.
