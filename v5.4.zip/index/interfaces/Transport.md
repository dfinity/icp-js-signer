---
title: Transport
editUrl: false
next: true
prev: true
---

Defined in: [src/transport.ts:28](https://github.com/dfinity/icp-js-signer/blob/05046af0774fe292d4b76290de5a787d2a119c35/src/transport.ts#L28)

## Methods

### establishChannel()

> **establishChannel**(): `Promise`\<[`Channel`](Channel.md)\>

Defined in: [src/transport.ts:29](https://github.com/dfinity/icp-js-signer/blob/05046af0774fe292d4b76290de5a787d2a119c35/src/transport.ts#L29)

#### Returns

`Promise`\<[`Channel`](Channel.md)\>
