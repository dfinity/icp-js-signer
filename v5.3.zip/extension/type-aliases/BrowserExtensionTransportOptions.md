---
title: BrowserExtensionTransportOptions
editUrl: false
next: true
prev: true
---

> **BrowserExtensionTransportOptions** = [`BrowserExtensionChannelOptions`](../interfaces/BrowserExtensionChannelOptions.md)

Defined in: [src/extension/browserExtensionTransport.ts:12](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/extension/browserExtensionTransport.ts#L12)

Options for creating a [BrowserExtensionTransport](../classes/BrowserExtensionTransport.md).
