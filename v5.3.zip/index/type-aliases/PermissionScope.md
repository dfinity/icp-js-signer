---
title: PermissionScope
editUrl: false
next: true
prev: true
---

> **PermissionScope** = `object` & `Record`\<`string`, `unknown`\>

Defined in: [src/signer.ts:88](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/signer.ts#L88)

A permission scope identifies a method and optionally additional
constraints (e.g. target canister IDs for delegations).

## Type Declaration

### method

> **method**: `string`

## See

https://github.com/dfinity/wg-identity-authentication/blob/main/topics/icrc_25_signer_interaction_standard.md
