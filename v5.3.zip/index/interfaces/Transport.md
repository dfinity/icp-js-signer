---
title: Transport
editUrl: false
next: true
prev: true
---

Defined in: [src/transport.ts:28](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/transport.ts#L28)

## Methods

### establishChannel()

> **establishChannel**(): `Promise`\<[`Channel`](Channel.md)\>

Defined in: [src/transport.ts:29](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/transport.ts#L29)

#### Returns

`Promise`\<[`Channel`](Channel.md)\>
