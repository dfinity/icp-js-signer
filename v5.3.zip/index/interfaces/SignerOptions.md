---
title: SignerOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/signer.ts:128](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/signer.ts#L128)

Options for creating a [Signer](../classes/Signer.md) instance.

## Type Parameters

### T

`T` *extends* [`Transport`](Transport.md)

## Properties

### autoCloseTransportChannel?

> `optional` **autoCloseTransportChannel?**: `boolean`

Defined in: [src/signer.ts:135](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/signer.ts#L135)

Automatically close the transport channel after a response is received.

#### Default

```ts
true
```

***

### closeTransportChannelAfter?

> `optional` **closeTransportChannelAfter?**: `number`

Defined in: [src/signer.ts:140](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/signer.ts#L140)

Delay in milliseconds before auto-closing the transport channel.

#### Default

```ts
200
```

***

### crypto?

> `optional` **crypto?**: `Pick`\<`Crypto`, `"randomUUID"`\>

Defined in: [src/signer.ts:145](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/signer.ts#L145)

Source of random UUIDs for JSON-RPC request IDs.

#### Default

```ts
globalThis.crypto
```

***

### derivationOrigin?

> `optional` **derivationOrigin?**: `string`

Defined in: [src/signer.ts:157](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/signer.ts#L157)

Derivation origin for ICRC-95 identity derivation.
When set, all requests include an `icrc95DerivationOrigin` param.

#### See

https://github.com/dfinity/wg-identity-authentication/blob/main/topics/icrc_95_derivationorigin.md

***

### transforms?

> `optional` **transforms?**: [`SignerRequestTransformFn`](../type-aliases/SignerRequestTransformFn.md)[]

Defined in: [src/signer.ts:151](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/signer.ts#L151)

Additional transform functions applied to each outgoing JSON-RPC request,
can be used to e.g. add additional params to every request as seen in ICRC-95.
Transforms are applied in order; each receives the output of the previous one.

***

### transport

> **transport**: `T`

Defined in: [src/signer.ts:130](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/signer.ts#L130)

The transport used to communicate with the signer.
