---
title: PostMessageTransportError
editUrl: false
next: true
prev: true
---

Defined in: [src/web/postMessageTransport.ts:9](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/web/postMessageTransport.ts#L9)

Error thrown by [PostMessageTransport](PostMessageTransport.md) for transport-level failures.

## Extends

- `Error`

## Constructors

### Constructor

> **new PostMessageTransportError**(`message?`): `PostMessageTransportError`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1080

#### Parameters

##### message?

`string`

#### Returns

`PostMessageTransportError`

#### Inherited from

`Error.constructor`

### Constructor

> **new PostMessageTransportError**(`message?`, `options?`): `PostMessageTransportError`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1080

#### Parameters

##### message?

`string`

##### options?

`ErrorOptions`

#### Returns

`PostMessageTransportError`

#### Inherited from

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: docs/node\_modules/typescript/lib/lib.es2022.error.d.ts:24

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1075

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1074

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.stack`
