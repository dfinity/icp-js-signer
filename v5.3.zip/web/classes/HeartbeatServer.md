---
title: HeartbeatServer
editUrl: false
next: true
prev: true
---

Defined in: [src/web/heartbeat/server.ts:42](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/web/heartbeat/server.ts#L42)

## Constructors

### Constructor

> **new HeartbeatServer**(`options`): `HeartbeatServer`

Defined in: [src/web/heartbeat/server.ts:45](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/web/heartbeat/server.ts#L45)

#### Parameters

##### options

[`HeartbeatServerOptions`](../interfaces/HeartbeatServerOptions.md)

#### Returns

`HeartbeatServer`

## Methods

### changeStatus()

> **changeStatus**(`status`): `void`

Defined in: [src/web/heartbeat/server.ts:58](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/web/heartbeat/server.ts#L58)

#### Parameters

##### status

`"pending"` \| `"ready"`

#### Returns

`void`
