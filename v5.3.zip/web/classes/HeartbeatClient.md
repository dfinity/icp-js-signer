---
title: HeartbeatClient
editUrl: false
next: true
prev: true
---

Defined in: [src/web/heartbeat/client.ts:60](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/web/heartbeat/client.ts#L60)

## Constructors

### Constructor

> **new HeartbeatClient**(`options`): `HeartbeatClient`

Defined in: [src/web/heartbeat/client.ts:64](https://github.com/dfinity/icp-js-signer/blob/29ede8f264f72eba7e63122964c2b2f3579dc5f3/src/web/heartbeat/client.ts#L64)

#### Parameters

##### options

[`HeartbeatClientOptions`](../interfaces/HeartbeatClientOptions.md)

#### Returns

`HeartbeatClient`
