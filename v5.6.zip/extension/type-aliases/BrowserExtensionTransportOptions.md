---
title: BrowserExtensionTransportOptions
editUrl: false
next: true
prev: true
---

> **BrowserExtensionTransportOptions** = [`BrowserExtensionChannelOptions`](../interfaces/BrowserExtensionChannelOptions.md)

Defined in: [src/extension/browserExtensionTransport.ts:12](https://github.com/dfinity/icp-js-signer/blob/8f460cf46f2b2c04d91850f1177b734d459d75f3/src/extension/browserExtensionTransport.ts#L12)

Options for creating a [BrowserExtensionTransport](../classes/BrowserExtensionTransport.md).
