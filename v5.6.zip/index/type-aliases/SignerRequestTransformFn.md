---
title: SignerRequestTransformFn
editUrl: false
next: true
prev: true
---

> **SignerRequestTransformFn** = (`request`) => `JsonRpcRequest`

Defined in: [src/signer.ts:158](https://github.com/dfinity/icp-js-signer/blob/8f460cf46f2b2c04d91850f1177b734d459d75f3/src/signer.ts#L158)

A function that transforms a JSON-RPC request before it is sent to the signer.
Transforms are applied in order and each receives the output of the previous one.

## Parameters

### request

`JsonRpcRequest`

## Returns

`JsonRpcRequest`
