---
title: Transport
editUrl: false
next: true
prev: true
---

Defined in: [src/transport.ts:28](https://github.com/dfinity/icp-js-signer/blob/8f460cf46f2b2c04d91850f1177b734d459d75f3/src/transport.ts#L28)

## Methods

### establishChannel()

> **establishChannel**(): `Promise`\<[`Channel`](Channel.md)\>

Defined in: [src/transport.ts:29](https://github.com/dfinity/icp-js-signer/blob/8f460cf46f2b2c04d91850f1177b734d459d75f3/src/transport.ts#L29)

#### Returns

`Promise`\<[`Channel`](Channel.md)\>
