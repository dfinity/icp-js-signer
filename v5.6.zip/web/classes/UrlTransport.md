---
title: UrlTransport
editUrl: false
next: true
prev: true
---

Defined in: [src/web/urlTransport.ts:106](https://github.com/dfinity/icp-js-signer/blob/8f460cf46f2b2c04d91850f1177b734d459d75f3/src/web/urlTransport.ts#L106)

ICRC-167 browser URL transport for communicating with web-based signers via
top-level navigation.

Unlike `PostMessageTransport`, this transport does not keep a live
`postMessage` channel. Each request navigates the current window to the
signer with the request in the URL hash fragment; the signer returns the
response in the fragment of `callbackUrl`. Because a top-level redirect
unloads the page, the transport keeps a call-order-keyed journal in
Storage and replays it on the return load — so calling code written
as `const x = await a(); const y = await b(x)` continues where it left off
across the redirect.

Run the calling code on the load of the flow's route: a fresh arrival and
the signer's return both land there, so re-running it starts the flow the
first time and replays it on the return. No resume or cleanup call is
needed — a signer return (a `message` matching the pending) continues the
flow; any other load starts a fresh one, ignoring a finished flow's leftover
journal. Issue the same requests and `memoize` steps in the same order on
every load (branch only on values recovered from earlier results), and route
any value a request depends on — such as a nonce — through `memoize` so it
stays stable across the redirect. See [UrlFlow](UrlFlow.md).

The journal is namespaced by `callbackUrl` by default, so a relying party
with several flows (each with its own callback) gets an isolated journal per
flow without configuring storage keys. An unfinished flow's journal expires
after `flowTimeout`, so an abandoned flow is not resumed later.

## See

https://github.com/dfinity/wg-identity-authentication/blob/main/topics/icrc_167_browser_url_transport.md

## Example

```ts
const transport = new UrlTransport({
  url: "https://id.ai/icrc-167",
  callbackUrl: "https://relying.example.com/signer-callback",
});
const signer = new Signer({ transport });

// On the load of the callback route (fresh arrival or signer return):
const nonce = await transport.memoize(() => fetchNonce());
const [attributes, delegation] = await Promise.all([
  signer.sendRequest({ jsonrpc: "2.0", id: 1, method: "attributes", params: { nonce } }),
  signer.requestDelegation({ publicKey, targets }),
]);
finish(nonce, attributes, delegation); // runs once, on completion
```

## Implements

- [`Transport`](../../index/interfaces/Transport.md)

## Constructors

### Constructor

> **new UrlTransport**(`options`): `UrlTransport`

Defined in: [src/web/urlTransport.ts:109](https://github.com/dfinity/icp-js-signer/blob/8f460cf46f2b2c04d91850f1177b734d459d75f3/src/web/urlTransport.ts#L109)

#### Parameters

##### options

[`UrlTransportOptions`](../interfaces/UrlTransportOptions.md)

#### Returns

`UrlTransport`

## Methods

### establishChannel()

> **establishChannel**(): `Promise`\<[`UrlChannel`](UrlChannel.md)\>

Defined in: [src/web/urlTransport.ts:137](https://github.com/dfinity/icp-js-signer/blob/8f460cf46f2b2c04d91850f1177b734d459d75f3/src/web/urlTransport.ts#L137)

Establishes a channel that drives this transport's shared flow journal.

#### Returns

`Promise`\<[`UrlChannel`](UrlChannel.md)\>

#### Implementation of

[`Transport`](../../index/interfaces/Transport.md).[`establishChannel`](../../index/interfaces/Transport.md#establishchannel)

***

### memoize()

#### Call Signature

> **memoize**\<`T`\>(`produce`): `Promise`\<`T`\>

Defined in: [src/web/urlTransport.ts:163](https://github.com/dfinity/icp-js-signer/blob/8f460cf46f2b2c04d91850f1177b734d459d75f3/src/web/urlTransport.ts#L163)

Performs any async work a flow needs other than a signer request — the
sole place a flow may `await` non-request async. It runs `produce` once,
journals its result in the same call-order record as requests, and replays
that result on the return load instead of re-running. This keeps a value
stable across the redirect (e.g. a single-use nonce the signer signs
against, which must not be re-fetched on return), whether it is a pre-step
or falls between requests.

Mirrors the producer's sync/async shape: a synchronous `produce` returns
its value directly, an asynchronous one returns a promise. A replay resolves
synchronously (the value is already journaled), so awaiting the result is
always safe — `await` on a non-promise is a no-op. Returning synchronously
lets a value be memoized where an `await` is not possible (e.g. read in a
constructor to configure a dependency) while staying stable across the
redirect.

Its result must be JSON-serializable, and it is subject to the same ordering
rule as requests: call `memoize` in a stable order across loads.

##### Type Parameters

###### T

`T`

##### Parameters

###### produce

() => `Promise`\<`T`\>

Produces the value to journal on the first load.

##### Returns

`Promise`\<`T`\>

The produced value, or the journaled value on a replay load.

#### Call Signature

> **memoize**\<`T`\>(`produce`): `T`

Defined in: [src/web/urlTransport.ts:164](https://github.com/dfinity/icp-js-signer/blob/8f460cf46f2b2c04d91850f1177b734d459d75f3/src/web/urlTransport.ts#L164)

Performs any async work a flow needs other than a signer request — the
sole place a flow may `await` non-request async. It runs `produce` once,
journals its result in the same call-order record as requests, and replays
that result on the return load instead of re-running. This keeps a value
stable across the redirect (e.g. a single-use nonce the signer signs
against, which must not be re-fetched on return), whether it is a pre-step
or falls between requests.

Mirrors the producer's sync/async shape: a synchronous `produce` returns
its value directly, an asynchronous one returns a promise. A replay resolves
synchronously (the value is already journaled), so awaiting the result is
always safe — `await` on a non-promise is a no-op. Returning synchronously
lets a value be memoized where an `await` is not possible (e.g. read in a
constructor to configure a dependency) while staying stable across the
redirect.

Its result must be JSON-serializable, and it is subject to the same ordering
rule as requests: call `memoize` in a stable order across loads.

##### Type Parameters

###### T

`T`

##### Parameters

###### produce

() => `T`

Produces the value to journal on the first load.

##### Returns

`T`

The produced value, or the journaled value on a replay load.
