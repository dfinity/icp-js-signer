---
title: HeartbeatClient
editUrl: false
next: true
prev: true
---

Defined in: [src/web/heartbeat/client.ts:60](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/heartbeat/client.ts#L60)

## Constructors

### Constructor

> **new HeartbeatClient**(`options`): `HeartbeatClient`

Defined in: [src/web/heartbeat/client.ts:64](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/heartbeat/client.ts#L64)

#### Parameters

##### options

[`HeartbeatClientOptions`](../interfaces/HeartbeatClientOptions.md)

#### Returns

`HeartbeatClient`
