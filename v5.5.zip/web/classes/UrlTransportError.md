---
title: UrlTransportError
editUrl: false
next: true
prev: true
---

Defined in: [src/web/urlTransport.ts:6](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlTransport.ts#L6)

Error thrown by [UrlTransport](UrlTransport.md) for transport-level failures.

## Extends

- `Error`

## Constructors

### Constructor

> **new UrlTransportError**(`message?`): `UrlTransportError`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1080

#### Parameters

##### message?

`string`

#### Returns

`UrlTransportError`

#### Inherited from

`Error.constructor`

### Constructor

> **new UrlTransportError**(`message?`, `options?`): `UrlTransportError`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1080

#### Parameters

##### message?

`string`

##### options?

`ErrorOptions`

#### Returns

`UrlTransportError`

#### Inherited from

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: docs/node\_modules/typescript/lib/lib.es2022.error.d.ts:24

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1075

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1074

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.stack`
