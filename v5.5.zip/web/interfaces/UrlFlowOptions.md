---
title: UrlFlowOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/web/urlFlow.ts:4](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlFlow.ts#L4)

Options for creating a [UrlFlow](../classes/UrlFlow.md).

## Properties

### callbackUrl

> **callbackUrl**: `string`

Defined in: [src/web/urlFlow.ts:8](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlFlow.ts#L8)

The relying party callback URL the signer returns the response to.

***

### crypto

> **crypto**: `Pick`\<`Crypto`, `"randomUUID"`\>

Defined in: [src/web/urlFlow.ts:23](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlFlow.ts#L23)

Source of random UUIDs for the `state` parameter.

***

### flowTimeout

> **flowTimeout**: `number`

Defined in: [src/web/urlFlow.ts:17](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlFlow.ts#L17)

Time in milliseconds after which an unfinished flow's persisted state is
considered stale and ignored (a new flow starts instead).

***

### history

> **history**: `Pick`\<`History`, `"replaceState"`\>

Defined in: [src/web/urlFlow.ts:21](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlFlow.ts#L21)

History used to strip the fragment after reading a response.

***

### location

> **location**: `Pick`\<`Location`, `"assign"` \| `"hash"` \| `"pathname"` \| `"search"`\>

Defined in: [src/web/urlFlow.ts:19](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlFlow.ts#L19)

Location used to read the callback and perform the redirect.

***

### now

> **now**: () => `number`

Defined in: [src/web/urlFlow.ts:25](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlFlow.ts#L25)

Clock used to timestamp flow state and expire it.

#### Returns

`number`

***

### storage

> **storage**: `Storage`

Defined in: [src/web/urlFlow.ts:10](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlFlow.ts#L10)

Storage used to persist flow progress across the redirect.

***

### storageKey

> **storageKey**: `string`

Defined in: [src/web/urlFlow.ts:12](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlFlow.ts#L12)

Key under which flow state is stored.

***

### url

> **url**: `string`

Defined in: [src/web/urlFlow.ts:6](https://github.com/dfinity/icp-js-signer/blob/f76e9ffcd832b4f2c8e32d46244aa447309ba192/src/web/urlFlow.ts#L6)

The signer's ICRC-167 transport URL.
