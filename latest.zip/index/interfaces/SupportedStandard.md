---
title: SupportedStandard
editUrl: false
next: true
prev: true
---

Defined in: [src/signer.ts:196](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L196)

A standard supported by the signer, as returned by
[Signer.getSupportedStandards](../classes/Signer.md#getsupportedstandards). The `name` field contains
the ICRC standard identifier (e.g. `"ICRC-27"`) and `url` points
to the specification.

## Properties

### name

> **name**: `string`

Defined in: [src/signer.ts:197](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L197)

***

### url

> **url**: `string`

Defined in: [src/signer.ts:198](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L198)
