---
title: SupportedStandard
editUrl: false
next: true
prev: true
---

Defined in: [src/signer.ts:207](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/signer.ts#L207)

A standard supported by the signer, as returned by
[Signer.getSupportedStandards](../classes/Signer.md#getsupportedstandards). The `name` field contains
the ICRC standard identifier (e.g. `"ICRC-27"`) and `url` points
to the specification.

## Properties

### name

> **name**: `string`

Defined in: [src/signer.ts:208](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/signer.ts#L208)

***

### url

> **url**: `string`

Defined in: [src/signer.ts:209](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/signer.ts#L209)
