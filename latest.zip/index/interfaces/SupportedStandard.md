---
title: SupportedStandard
editUrl: false
next: true
prev: true
---

Defined in: [src/signer.ts:207](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/signer.ts#L207)

A standard supported by the signer, as returned by
[Signer.getSupportedStandards](../classes/Signer.md#getsupportedstandards). The `name` field contains
the ICRC standard identifier (e.g. `"ICRC-27"`) and `url` points
to the specification.

## Properties

### name

> **name**: `string`

Defined in: [src/signer.ts:208](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/signer.ts#L208)

***

### url

> **url**: `string`

Defined in: [src/signer.ts:209](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/signer.ts#L209)
