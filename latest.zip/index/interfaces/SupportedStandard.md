---
title: SupportedStandard
editUrl: false
next: true
prev: true
---

Defined in: [src/signer.ts:104](https://github.com/dfinity/icp-js-signer/blob/1a47a21a30931a60a5e13300c1e76851de5ad094/src/signer.ts#L104)

A standard supported by the signer, as returned by
[Signer.getSupportedStandards](../classes/Signer.md#getsupportedstandards). The `name` field contains
the ICRC standard identifier (e.g. `"ICRC-27"`) and `url` points
to the specification.

## Properties

### name

> **name**: `string`

Defined in: [src/signer.ts:105](https://github.com/dfinity/icp-js-signer/blob/1a47a21a30931a60a5e13300c1e76851de5ad094/src/signer.ts#L105)

***

### url

> **url**: `string`

Defined in: [src/signer.ts:106](https://github.com/dfinity/icp-js-signer/blob/1a47a21a30931a60a5e13300c1e76851de5ad094/src/signer.ts#L106)
