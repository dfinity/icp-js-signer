---
title: Transport
editUrl: false
next: true
prev: true
---

Defined in: [src/transport.ts:28](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/transport.ts#L28)

## Methods

### establishChannel()

> **establishChannel**(): `Promise`\<[`Channel`](Channel.md)\>

Defined in: [src/transport.ts:29](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/transport.ts#L29)

#### Returns

`Promise`\<[`Channel`](Channel.md)\>
