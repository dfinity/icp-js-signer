---
title: Transport
editUrl: false
next: true
prev: true
---

Defined in: [src/transport.ts:28](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/transport.ts#L28)

## Methods

### establishChannel()

> **establishChannel**(): `Promise`\<[`Channel`](Channel.md)\>

Defined in: [src/transport.ts:29](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/transport.ts#L29)

#### Returns

`Promise`\<[`Channel`](Channel.md)\>
