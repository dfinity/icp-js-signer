---
title: SignerOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/signer.ts:220](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L220)

Options for creating a [Signer](../classes/Signer.md) instance.

## Type Parameters

### T

`T` *extends* [`Transport`](Transport.md)

## Properties

### autoCloseTransportChannel?

> `optional` **autoCloseTransportChannel?**: `boolean`

Defined in: [src/signer.ts:227](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L227)

Automatically close the transport channel after a response is received.

#### Default

```ts
true
```

***

### closeTransportChannelAfter?

> `optional` **closeTransportChannelAfter?**: `number`

Defined in: [src/signer.ts:232](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L232)

Delay in milliseconds before auto-closing the transport channel.

#### Default

```ts
200
```

***

### crypto?

> `optional` **crypto?**: `Pick`\<`Crypto`, `"randomUUID"`\>

Defined in: [src/signer.ts:237](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L237)

Source of random UUIDs for JSON-RPC request IDs.

#### Default

```ts
globalThis.crypto
```

***

### derivationOrigin?

> `optional` **derivationOrigin?**: `string`

Defined in: [src/signer.ts:249](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L249)

Derivation origin for ICRC-95 identity derivation.
When set, all requests include an `icrc95DerivationOrigin` param.

#### See

https://github.com/dfinity/wg-identity-authentication/blob/main/topics/icrc_95_derivationorigin.md

***

### transforms?

> `optional` **transforms?**: [`SignerRequestTransformFn`](../type-aliases/SignerRequestTransformFn.md)[]

Defined in: [src/signer.ts:243](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L243)

Additional transform functions applied to each outgoing JSON-RPC request,
can be used to e.g. add additional params to every request as seen in ICRC-95.
Transforms are applied in order; each receives the output of the previous one.

***

### transport

> **transport**: `T`

Defined in: [src/signer.ts:222](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L222)

The transport used to communicate with the signer.
