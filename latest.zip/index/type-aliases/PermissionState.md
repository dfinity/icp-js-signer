---
title: PermissionState
editUrl: false
next: true
prev: true
---

> **PermissionState** = `"denied"` \| `"ask_on_use"` \| `"granted"`

Defined in: [src/signer.ts:96](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/signer.ts#L96)

The state of a permission scope as reported by the signer.
- `granted` — the relying party may call the method without further approval.
- `denied` — the signer will reject calls to the method.
- `ask_on_use` — the signer will prompt the user when the method is called.
