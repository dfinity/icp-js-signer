---
title: PermissionScope
editUrl: false
next: true
prev: true
---

> **PermissionScope** = `object` & `Record`\<`string`, `unknown`\>

Defined in: [src/signer.ts:180](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/signer.ts#L180)

A permission scope identifies a method and optionally additional
constraints (e.g. target canister IDs for delegations).

## Type Declaration

### method

> **method**: `string`

## See

https://github.com/dfinity/wg-identity-authentication/blob/main/topics/icrc_25_signer_interaction_standard.md
