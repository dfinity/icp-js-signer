---
title: PermissionScope
editUrl: false
next: true
prev: true
---

> **PermissionScope** = `object` & `Record`\<`string`, `unknown`\>

Defined in: [src/signer.ts:191](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/signer.ts#L191)

A permission scope identifies a method and optionally additional
constraints (e.g. target canister IDs for delegations).

## Type Declaration

### method

> **method**: `string`

## See

https://github.com/dfinity/wg-identity-authentication/blob/main/topics/icrc_25_signer_interaction_standard.md
