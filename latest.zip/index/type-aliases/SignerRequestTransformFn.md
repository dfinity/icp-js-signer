---
title: SignerRequestTransformFn
editUrl: false
next: true
prev: true
---

> **SignerRequestTransformFn** = (`request`) => `JsonRpcRequest`

Defined in: [src/signer.ts:55](https://github.com/dfinity/icp-js-signer/blob/1a47a21a30931a60a5e13300c1e76851de5ad094/src/signer.ts#L55)

A function that transforms a JSON-RPC request before it is sent to the signer.
Transforms are applied in order and each receives the output of the previous one.

## Parameters

### request

`JsonRpcRequest`

## Returns

`JsonRpcRequest`
