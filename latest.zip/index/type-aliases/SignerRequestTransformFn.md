---
title: SignerRequestTransformFn
editUrl: false
next: true
prev: true
---

> **SignerRequestTransformFn** = (`request`) => `JsonRpcRequest`

Defined in: [src/signer.ts:158](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/signer.ts#L158)

A function that transforms a JSON-RPC request before it is sent to the signer.
Transforms are applied in order and each receives the output of the previous one.

## Parameters

### request

`JsonRpcRequest`

## Returns

`JsonRpcRequest`
