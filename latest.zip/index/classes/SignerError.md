---
title: SignerError
editUrl: false
next: true
prev: true
---

Defined in: [src/signer.ts:216](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/signer.ts#L216)

Error thrown when a signer returns a JSON-RPC error response
or when a transport-level failure occurs.

## Extends

- `Error`

## Constructors

### Constructor

> **new SignerError**(`error`, `options?`): `SignerError`

Defined in: [src/signer.ts:222](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/signer.ts#L222)

#### Parameters

##### error

`JsonRpcError`

##### options?

`ErrorOptions`

#### Returns

`SignerError`

#### Overrides

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: docs/node\_modules/typescript/lib/lib.es2022.error.d.ts:24

#### Inherited from

`Error.cause`

***

### code

> **code**: `number`

Defined in: [src/signer.ts:218](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/signer.ts#L218)

The JSON-RPC error code.

***

### data?

> `optional` **data?**: `unknown`

Defined in: [src/signer.ts:220](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/signer.ts#L220)

Optional additional error data from the signer.

***

### message

> **message**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1075

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1074

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.stack`
