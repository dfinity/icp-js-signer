---
title: UrlFlowOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/web/urlFlow.ts:28](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/urlFlow.ts#L28)

Options for creating a [UrlFlow](../classes/UrlFlow.md).

## Properties

### callbackUrl

> **callbackUrl**: `string`

Defined in: [src/web/urlFlow.ts:32](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/urlFlow.ts#L32)

The relying party callback URL the signer returns the response to.

***

### crypto

> **crypto**: `Pick`\<`Crypto`, `"randomUUID"`\>

Defined in: [src/web/urlFlow.ts:47](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/urlFlow.ts#L47)

Source of random UUIDs for the `state` parameter.

***

### flowTimeout

> **flowTimeout**: `number`

Defined in: [src/web/urlFlow.ts:41](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/urlFlow.ts#L41)

Time in milliseconds after which an unfinished flow's persisted state is
considered stale and ignored (a new flow starts instead).

***

### history

> **history**: `Pick`\<`History`, `"replaceState"`\>

Defined in: [src/web/urlFlow.ts:45](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/urlFlow.ts#L45)

History used to strip the fragment after reading a response.

***

### location

> **location**: `Pick`\<`Location`, `"assign"` \| `"hash"` \| `"pathname"` \| `"search"`\>

Defined in: [src/web/urlFlow.ts:43](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/urlFlow.ts#L43)

Location used to read the callback and perform the redirect.

***

### now

> **now**: () => `number`

Defined in: [src/web/urlFlow.ts:49](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/urlFlow.ts#L49)

Clock used to timestamp flow state and expire it.

#### Returns

`number`

***

### storage

> **storage**: `Storage`

Defined in: [src/web/urlFlow.ts:34](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/urlFlow.ts#L34)

Storage used to persist flow progress across the redirect.

***

### storageKey

> **storageKey**: `string`

Defined in: [src/web/urlFlow.ts:36](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/urlFlow.ts#L36)

Key under which flow state is stored.

***

### url

> **url**: `string`

Defined in: [src/web/urlFlow.ts:30](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/urlFlow.ts#L30)

The signer's ICRC-167 transport URL.
