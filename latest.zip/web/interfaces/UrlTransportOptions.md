---
title: UrlTransportOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/web/urlTransport.ts:9](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlTransport.ts#L9)

Options for creating a [UrlTransport](../classes/UrlTransport.md).

## Properties

### callbackUrl

> **callbackUrl**: `string`

Defined in: [src/web/urlTransport.ts:18](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlTransport.ts#L18)

The relying party callback URL the signer returns the response to. Must be
an absolute URL, on an origin the relying party controls, declared in that
origin's `/.well-known/ii-auth-callbacks` allow-list, and must not contain
a fragment (the transport appends its own).

***

### crypto?

> `optional` **crypto?**: `Pick`\<`Crypto`, `"randomUUID"`\>

Defined in: [src/web/urlTransport.ts:58](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlTransport.ts#L58)

Source of random UUIDs for the `state` parameter.

#### Default

```ts
globalThis.crypto
```

***

### flowTimeout?

> `optional` **flowTimeout?**: `number`

Defined in: [src/web/urlTransport.ts:38](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlTransport.ts#L38)

Time in milliseconds after which an unfinished flow's persisted state is
considered stale and ignored, so an abandoned flow (and any single-use
value it captured, such as a nonce) is not resumed later.

#### Default

```ts
600000
```

***

### history?

> `optional` **history?**: `Pick`\<`History`, `"replaceState"`\>

Defined in: [src/web/urlTransport.ts:53](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlTransport.ts#L53)

History used to strip the fragment after reading a response.

#### Default

```ts
globalThis.history
```

***

### location?

> `optional` **location?**: `Pick`\<`Location`, `"assign"` \| `"hash"` \| `"pathname"` \| `"search"`\>

Defined in: [src/web/urlTransport.ts:48](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlTransport.ts#L48)

Location used to read the callback and perform the redirect.

#### Default

```ts
globalThis.location
```

***

### now?

> `optional` **now?**: () => `number`

Defined in: [src/web/urlTransport.ts:43](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlTransport.ts#L43)

Clock used to timestamp and expire flow state.

#### Returns

`number`

#### Default

```ts
() => Date.now()
```

***

### storage?

> `optional` **storage?**: `Storage`

Defined in: [src/web/urlTransport.ts:24](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlTransport.ts#L24)

Storage used to persist flow progress across the top-level redirect.
Use `sessionStorage` so the flow does not outlive the browsing session.

#### Default

```ts
globalThis.sessionStorage
```

***

### storageKey?

> `optional` **storageKey?**: `string`

Defined in: [src/web/urlTransport.ts:31](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlTransport.ts#L31)

Key under which flow state is persisted. Defaults to a key derived from
`callbackUrl`, so each flow (which has its own callback) gets its own
journal automatically — set this only to override that namespacing.

#### Default

`icrc167:flow:${callbackUrl}`

***

### url

> **url**: `string`

Defined in: [src/web/urlTransport.ts:11](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlTransport.ts#L11)

The signer's ICRC-167 transport URL. Must be a secure context (HTTPS, localhost, or 127.0.0.1).
