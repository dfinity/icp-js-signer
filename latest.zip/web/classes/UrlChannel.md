---
title: UrlChannel
editUrl: false
next: true
prev: true
---

Defined in: [src/web/urlChannel.ts:22](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlChannel.ts#L22)

A [Channel](../../index/interfaces/Channel.md) implementation for the ICRC-167 browser URL transport,
driving a shared [UrlFlow](UrlFlow.md) journal.

Each request either resolves from the journal (a replayed call on the return
load) or is buffered for the next redirect. Concurrently issued requests are
coalesced by the flow into a single JSON-RPC batch and one redirect. When the
redirect fires the page unloads, so the caller's awaited response never
arrives on this load — it arrives on the return load, when the calling code
replays this request and it resolves from the journal.

Callers need no explicit resume or cleanup step: a signer return continues
the flow, and any other load starts a fresh one. Issue the same requests (and
`memoize` steps) in the same order on every load, and route any value a
request depends on through `memoize` so it stays stable across the redirect;
see [UrlFlow](UrlFlow.md) and the module README for the replay contract.

## See

https://github.com/dfinity/wg-identity-authentication/blob/main/topics/icrc_167_browser_url_transport.md

## Implements

- [`Channel`](../../index/interfaces/Channel.md)

## Constructors

### Constructor

> **new UrlChannel**(`flow`): `UrlChannel`

Defined in: [src/web/urlChannel.ts:28](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlChannel.ts#L28)

#### Parameters

##### flow

[`UrlFlow`](UrlFlow.md)

#### Returns

`UrlChannel`

## Accessors

### closed

#### Get Signature

> **get** **closed**(): `boolean`

Defined in: [src/web/urlChannel.ts:33](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlChannel.ts#L33)

Whether this channel has been closed.

##### Returns

`boolean`

#### Implementation of

[`Channel`](../../index/interfaces/Channel.md).[`closed`](../../index/interfaces/Channel.md#closed)

## Methods

### addEventListener()

> **addEventListener**(...`__namedParameters`): () => `void`

Defined in: [src/web/urlChannel.ts:37](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlChannel.ts#L37)

#### Parameters

##### \_\_namedParameters

\[`"close"`, () => `void`\] \| \[`"response"`, (`response`) => `void`\]

#### Returns

() => `void`

#### Implementation of

[`Channel`](../../index/interfaces/Channel.md).[`addEventListener`](../../index/interfaces/Channel.md#addeventlistener)

***

### close()

> **close**(): `Promise`\<`void`\>

Defined in: [src/web/urlChannel.ts:94](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlChannel.ts#L94)

Marks the channel closed and notifies all close listeners.

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`Channel`](../../index/interfaces/Channel.md).[`close`](../../index/interfaces/Channel.md#close)

***

### send()

> **send**(`request`): `Promise`\<`void`\>

Defined in: [src/web/urlChannel.ts:61](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlChannel.ts#L61)

Resolves the request from the journal if the flow has already reached this
call, otherwise buffers it for the next redirect.

#### Parameters

##### request

`JsonRpcRequest`

The JSON-RPC request to send.

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`Channel`](../../index/interfaces/Channel.md).[`send`](../../index/interfaces/Channel.md#send)
