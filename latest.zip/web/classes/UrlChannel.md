---
title: UrlChannel
editUrl: false
next: true
prev: true
---

Defined in: [src/web/urlChannel.ts:27](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/web/urlChannel.ts#L27)

A [Channel](../../index/interfaces/Channel.md) implementation for the ICRC-167 browser URL transport,
driving a shared [UrlFlow](UrlFlow.md) journal.

Each request either resolves from the journal (a replayed call on the return
load) or is buffered for the next redirect. Concurrently issued requests are
coalesced by the flow into a single JSON-RPC batch and one redirect. When the
redirect fires the page unloads, so the caller's awaited response never
arrives on this load — it arrives on the return load, when the calling code
replays this request and it resolves from the journal.

Callers need no explicit resume or cleanup step: a signer return continues
the flow, and any other load starts a fresh one. Issue the same requests (and
`memoize` steps) in the same order on every load, and route any value a
request depends on through `memoize` so it stays stable across the redirect;
see [UrlFlow](UrlFlow.md) and the module README for the replay contract.

## See

https://github.com/dfinity/wg-identity-authentication/blob/main/topics/icrc_167_browser_url_transport.md

## Implements

- [`Channel`](../../index/interfaces/Channel.md)

## Constructors

### Constructor

> **new UrlChannel**(`flow`): `UrlChannel`

Defined in: [src/web/urlChannel.ts:33](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/web/urlChannel.ts#L33)

#### Parameters

##### flow

[`UrlFlow`](UrlFlow.md)

#### Returns

`UrlChannel`

## Accessors

### closed

#### Get Signature

> **get** **closed**(): `boolean`

Defined in: [src/web/urlChannel.ts:38](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/web/urlChannel.ts#L38)

Whether this channel has been closed.

##### Returns

`boolean`

#### Implementation of

[`Channel`](../../index/interfaces/Channel.md).[`closed`](../../index/interfaces/Channel.md#closed)

## Methods

### addEventListener()

> **addEventListener**(...`__namedParameters`): () => `void`

Defined in: [src/web/urlChannel.ts:42](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/web/urlChannel.ts#L42)

#### Parameters

##### \_\_namedParameters

\[`"close"`, () => `void`\] \| \[`"response"`, (`response`) => `void`\]

#### Returns

() => `void`

#### Implementation of

[`Channel`](../../index/interfaces/Channel.md).[`addEventListener`](../../index/interfaces/Channel.md#addeventlistener)

***

### close()

> **close**(): `Promise`\<`void`\>

Defined in: [src/web/urlChannel.ts:108](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/web/urlChannel.ts#L108)

Marks the channel closed and notifies all close listeners.

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`Channel`](../../index/interfaces/Channel.md).[`close`](../../index/interfaces/Channel.md#close)

***

### send()

> **send**(`request`): `Promise`\<`void`\>

Defined in: [src/web/urlChannel.ts:66](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/web/urlChannel.ts#L66)

Resolves the request from the journal if the flow has already reached this
call, otherwise buffers it for the next redirect.

#### Parameters

##### request

`JsonRpcRequest`

The JSON-RPC request to send.

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`Channel`](../../index/interfaces/Channel.md).[`send`](../../index/interfaces/Channel.md#send)
