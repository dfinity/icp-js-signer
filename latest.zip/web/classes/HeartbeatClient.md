---
title: HeartbeatClient
editUrl: false
next: true
prev: true
---

Defined in: [src/web/heartbeat/client.ts:60](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/heartbeat/client.ts#L60)

## Constructors

### Constructor

> **new HeartbeatClient**(`options`): `HeartbeatClient`

Defined in: [src/web/heartbeat/client.ts:64](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/heartbeat/client.ts#L64)

#### Parameters

##### options

[`HeartbeatClientOptions`](../interfaces/HeartbeatClientOptions.md)

#### Returns

`HeartbeatClient`
