---
title: HeartbeatClient
editUrl: false
next: true
prev: true
---

Defined in: [src/web/heartbeat/client.ts:60](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/heartbeat/client.ts#L60)

## Constructors

### Constructor

> **new HeartbeatClient**(`options`): `HeartbeatClient`

Defined in: [src/web/heartbeat/client.ts:64](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/heartbeat/client.ts#L64)

#### Parameters

##### options

[`HeartbeatClientOptions`](../interfaces/HeartbeatClientOptions.md)

#### Returns

`HeartbeatClient`
