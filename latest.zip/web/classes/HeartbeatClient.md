---
title: HeartbeatClient
editUrl: false
next: true
prev: true
---

Defined in: [src/web/heartbeat/client.ts:60](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/heartbeat/client.ts#L60)

## Constructors

### Constructor

> **new HeartbeatClient**(`options`): `HeartbeatClient`

Defined in: [src/web/heartbeat/client.ts:64](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/heartbeat/client.ts#L64)

#### Parameters

##### options

[`HeartbeatClientOptions`](../interfaces/HeartbeatClientOptions.md)

#### Returns

`HeartbeatClient`
