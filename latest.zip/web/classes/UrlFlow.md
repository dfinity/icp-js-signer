---
title: UrlFlow
editUrl: false
next: true
prev: true
---

Defined in: [src/web/urlFlow.ts:131](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlFlow.ts#L131)

The shared journal for one URL-transport flow (one page load).

A single call-order-keyed record of results is shared by memoized steps and
signer requests, and persisted across the top-level redirect. Concurrently
issued requests are coalesced into one JSON-RPC batch and one redirect.

A load continues an existing flow only when it is a signer **return** — the
URL carries a `message` matching the stored `pending`. In that case the
returned responses are folded into the journal and the calling code replays
from it (already-completed calls resolve from storage instead of navigating
again). Any other load — a bare visit to the callback, a leftover completed
journal, or an abandoned `pending` with no `message` — starts a **fresh**
flow: the stored journal is ignored and overwritten by the first request. So
navigating to the callback always starts the flow, and there is no separate
"clear" step — a finished flow's journal is simply inert to the next one.
(`flowTimeout` is a backstop for the storage entry.)

## Constructors

### Constructor

> **new UrlFlow**(`options`): `UrlFlow`

Defined in: [src/web/urlFlow.ts:152](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlFlow.ts#L152)

#### Parameters

##### options

[`UrlFlowOptions`](../interfaces/UrlFlowOptions.md)

#### Returns

`UrlFlow`

## Methods

### get()

> **get**(`index`): `unknown`

Defined in: [src/web/urlFlow.ts:218](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlFlow.ts#L218)

The stored result for a slot, or `undefined` if it has not completed.

#### Parameters

##### index

`number`

The call-order slot to read.

#### Returns

`unknown`

***

### memoize()

#### Call Signature

> **memoize**\<`T`\>(`produce`): `Promise`\<`T`\>

Defined in: [src/web/urlFlow.ts:252](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlFlow.ts#L252)

The core journaled step: runs `produce` once for its call-order slot and
records the result, or returns the recorded result on a replay load
without running `produce` again. This is what `UrlTransport.memoize`
exposes for any async work other than a signer request (e.g. fetching a
single-use nonce), and it shares its call-order counter with requests.

##### Type Parameters

###### T

`T`

##### Parameters

###### produce

() => `Promise`\<`T`\>

Produces the value on the first load; awaited if a promise.

##### Returns

`Promise`\<`T`\>

The produced value, or the journaled value on a replay load.

#### Call Signature

> **memoize**\<`T`\>(`produce`): `T`

Defined in: [src/web/urlFlow.ts:253](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlFlow.ts#L253)

The core journaled step: runs `produce` once for its call-order slot and
records the result, or returns the recorded result on a replay load
without running `produce` again. This is what `UrlTransport.memoize`
exposes for any async work other than a signer request (e.g. fetching a
single-use nonce), and it shares its call-order counter with requests.

##### Type Parameters

###### T

`T`

##### Parameters

###### produce

() => `T`

Produces the value on the first load; awaited if a promise.

##### Returns

`T`

The produced value, or the journaled value on a replay load.

***

### next()

> **next**(): `number`

Defined in: [src/web/urlFlow.ts:210](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlFlow.ts#L210)

Reserves the next call-order slot.

#### Returns

`number`

***

### recordedRequestKey()

> **recordedRequestKey**(`index`): `string` \| `undefined`

Defined in: [src/web/urlFlow.ts:227](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlFlow.ts#L227)

The content fingerprint recorded for a request slot, or `undefined` if no
request was journaled there. Used by the channel's replay divergence guard.

#### Parameters

##### index

`number`

The call-order slot to read.

#### Returns

`string` \| `undefined`

***

### request()

> **request**(`index`, `request`, `key`): `void`

Defined in: [src/web/urlFlow.ts:237](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/web/urlFlow.ts#L237)

Buffers an uncached request for the next redirect.

#### Parameters

##### index

`number`

The call-order slot reserved for the request.

##### request

`JsonRpcRequest`

The JSON-RPC request to send on the next redirect.

##### key

`string`

Content fingerprint recorded for the divergence guard.

#### Returns

`void`
