---
title: UrlFlow
editUrl: false
next: true
prev: true
---

Defined in: [src/web/urlFlow.ts:101](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlFlow.ts#L101)

The shared journal for one URL-transport flow (one page load).

A single call-order-keyed record of results is shared by memoized steps and
signer requests, and persisted across the top-level redirect. Concurrently
issued requests are coalesced into one JSON-RPC batch and one redirect.

A load continues an existing flow only when it is a signer **return** — the
URL carries a `message` matching the stored `pending`. In that case the
returned responses are folded into the journal and the calling code replays
from it (already-completed calls resolve from storage instead of navigating
again). Any other load — a bare visit to the callback, a leftover completed
journal, or an abandoned `pending` with no `message` — starts a **fresh**
flow: the stored journal is ignored and overwritten by the first request. So
navigating to the callback always starts the flow, and there is no separate
"clear" step — a finished flow's journal is simply inert to the next one.
(`flowTimeout` is a backstop for the storage entry.)

## Constructors

### Constructor

> **new UrlFlow**(`options`): `UrlFlow`

Defined in: [src/web/urlFlow.ts:119](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlFlow.ts#L119)

#### Parameters

##### options

[`UrlFlowOptions`](../interfaces/UrlFlowOptions.md)

#### Returns

`UrlFlow`

## Methods

### get()

> **get**(`index`): `unknown`

Defined in: [src/web/urlFlow.ts:184](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlFlow.ts#L184)

The stored result for a slot, or `undefined` if it has not completed.

#### Parameters

##### index

`number`

The call-order slot to read.

#### Returns

`unknown`

***

### memoize()

#### Call Signature

> **memoize**\<`T`\>(`produce`): `Promise`\<`T`\>

Defined in: [src/web/urlFlow.ts:207](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlFlow.ts#L207)

The core journaled step: runs `produce` once for its call-order slot and
records the result, or returns the recorded result on a replay load
without running `produce` again. This is what `UrlTransport.memoize`
exposes for any async work other than a signer request (e.g. fetching a
single-use nonce), and it shares its call-order counter with requests.

##### Type Parameters

###### T

`T`

##### Parameters

###### produce

() => `Promise`\<`T`\>

Produces the value on the first load; awaited if a promise.

##### Returns

`Promise`\<`T`\>

The produced value, or the journaled value on a replay load.

#### Call Signature

> **memoize**\<`T`\>(`produce`): `T`

Defined in: [src/web/urlFlow.ts:208](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlFlow.ts#L208)

The core journaled step: runs `produce` once for its call-order slot and
records the result, or returns the recorded result on a replay load
without running `produce` again. This is what `UrlTransport.memoize`
exposes for any async work other than a signer request (e.g. fetching a
single-use nonce), and it shares its call-order counter with requests.

##### Type Parameters

###### T

`T`

##### Parameters

###### produce

() => `T`

Produces the value on the first load; awaited if a promise.

##### Returns

`T`

The produced value, or the journaled value on a replay load.

***

### next()

> **next**(): `number`

Defined in: [src/web/urlFlow.ts:176](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlFlow.ts#L176)

Reserves the next call-order slot.

#### Returns

`number`

***

### request()

> **request**(`index`, `request`): `void`

Defined in: [src/web/urlFlow.ts:193](https://github.com/dfinity/icp-js-signer/blob/bc89691a1c0ef9449d7ce18451cca3855cb8fd6d/src/web/urlFlow.ts#L193)

Buffers an uncached request for the next redirect.

#### Parameters

##### index

`number`

The call-order slot reserved for the request.

##### request

`JsonRpcRequest`

The JSON-RPC request to send on the next redirect.

#### Returns

`void`
