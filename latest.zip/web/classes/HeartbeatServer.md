---
title: HeartbeatServer
editUrl: false
next: true
prev: true
---

Defined in: [src/web/heartbeat/server.ts:42](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/heartbeat/server.ts#L42)

## Constructors

### Constructor

> **new HeartbeatServer**(`options`): `HeartbeatServer`

Defined in: [src/web/heartbeat/server.ts:45](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/heartbeat/server.ts#L45)

#### Parameters

##### options

[`HeartbeatServerOptions`](../interfaces/HeartbeatServerOptions.md)

#### Returns

`HeartbeatServer`

## Methods

### changeStatus()

> **changeStatus**(`status`): `void`

Defined in: [src/web/heartbeat/server.ts:58](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/web/heartbeat/server.ts#L58)

#### Parameters

##### status

`"pending"` \| `"ready"`

#### Returns

`void`
