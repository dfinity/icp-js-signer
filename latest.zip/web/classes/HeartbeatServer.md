---
title: HeartbeatServer
editUrl: false
next: true
prev: true
---

Defined in: [src/web/heartbeat/server.ts:42](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/web/heartbeat/server.ts#L42)

## Constructors

### Constructor

> **new HeartbeatServer**(`options`): `HeartbeatServer`

Defined in: [src/web/heartbeat/server.ts:45](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/web/heartbeat/server.ts#L45)

#### Parameters

##### options

[`HeartbeatServerOptions`](../interfaces/HeartbeatServerOptions.md)

#### Returns

`HeartbeatServer`

## Methods

### changeStatus()

> **changeStatus**(`status`): `void`

Defined in: [src/web/heartbeat/server.ts:58](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/web/heartbeat/server.ts#L58)

#### Parameters

##### status

`"pending"` \| `"ready"`

#### Returns

`void`
