---
title: SignerAgentOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/agent/agent.ts:59](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/agent/agent.ts#L59)

Options for creating a [SignerAgent](../classes/SignerAgent.md).

## Type Parameters

### T

`T` *extends* [`Transport`](../../index/interfaces/Transport.md) = [`Transport`](../../index/interfaces/Transport.md)

## Properties

### account

> **account**: `Principal`

Defined in: [src/agent/agent.ts:63](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/agent/agent.ts#L63)

The principal of the account on whose behalf canister calls are made.

***

### agent?

> `optional` **agent?**: `HttpAgent`

Defined in: [src/agent/agent.ts:68](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/agent/agent.ts#L68)

An HttpAgent used for fetching the root key and status.

#### Default

```ts
A new HttpAgent connected to the IC mainnet.
```

***

### crypto?

> `optional` **crypto?**: `Pick`\<`Crypto`, `"getRandomValues"`\>

Defined in: [src/agent/agent.ts:73](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/agent/agent.ts#L73)

Source of randomness for nonces bound to upgraded query calls.

#### Default

```ts
globalThis.crypto
```

***

### signer

> **signer**: [`Signer`](../../index/classes/Signer.md)\<`T`\>

Defined in: [src/agent/agent.ts:61](https://github.com/dfinity/icp-js-signer/blob/b5504d303708e1fe79813a2b87fa6408fa935f40/src/agent/agent.ts#L61)

The [Signer](../../index/classes/Signer.md) used to send ICRC-49 canister call requests.
