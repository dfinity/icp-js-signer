---
title: BrowserExtensionTransportOptions
editUrl: false
next: true
prev: true
---

> **BrowserExtensionTransportOptions** = [`BrowserExtensionChannelOptions`](../interfaces/BrowserExtensionChannelOptions.md)

Defined in: [src/extension/browserExtensionTransport.ts:12](https://github.com/dfinity/icp-js-signer/blob/d3b1d5836b146824ee9d41b7a83c6118e510e1e3/src/extension/browserExtensionTransport.ts#L12)

Options for creating a [BrowserExtensionTransport](../classes/BrowserExtensionTransport.md).
