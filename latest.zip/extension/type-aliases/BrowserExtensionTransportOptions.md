---
title: BrowserExtensionTransportOptions
editUrl: false
next: true
prev: true
---

> **BrowserExtensionTransportOptions** = [`BrowserExtensionChannelOptions`](../interfaces/BrowserExtensionChannelOptions.md)

Defined in: [src/extension/browserExtensionTransport.ts:12](https://github.com/dfinity/icp-js-signer/blob/1a47a21a30931a60a5e13300c1e76851de5ad094/src/extension/browserExtensionTransport.ts#L12)

Options for creating a [BrowserExtensionTransport](../classes/BrowserExtensionTransport.md).
