---
title: BrowserExtensionTransportOptions
editUrl: false
next: true
prev: true
---

> **BrowserExtensionTransportOptions** = [`BrowserExtensionChannelOptions`](../interfaces/BrowserExtensionChannelOptions.md)

Defined in: [src/extension/browserExtensionTransport.ts:12](https://github.com/dfinity/icp-js-signer/blob/8fbb60dc9ba56cf4a9446b788427217df2a3f1d2/src/extension/browserExtensionTransport.ts#L12)

Options for creating a [BrowserExtensionTransport](../classes/BrowserExtensionTransport.md).
